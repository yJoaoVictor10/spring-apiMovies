package br.com.fiap.movies.models;


import lombok.AllArgsConstructor;
import lombok.Data;


import java.time.LocalDate;

@Data // @Data tem getter, setter, constructor, hash e equals
@AllArgsConstructor
public class Movie {
    private String title;
    private String synopsis;
    private Integer rating;
    private LocalDate releaseDate;
}
